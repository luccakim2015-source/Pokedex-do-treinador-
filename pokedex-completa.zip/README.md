# Minha Pokédex

Aplicativo web instalável (PWA), em português, com busca de Pokémon, filtro por geração, favoritos e lista de capturados.

## Arquivos
- `index.html`: estrutura da página
- `style.css`: aparência responsiva
- `script.js`: busca e interação com a PokéAPI
- `manifest.json`: configura instalação na tela inicial
- `sw.js`: cache dos arquivos principais
- `icon-192.png` e `icon-512.png`: ícones do app

## Publicar pelo GitHub no Android
1. Extraia `pokedex-completa.zip` no celular.
2. Abra seu repositório no GitHub pelo navegador.
3. Use **Add file → Upload files** e envie todos os arquivos extraídos (não envie apenas o ZIP).
4. Toque em **Commit changes**.
5. Abra **Settings → Pages**. Em **Build and deployment**, selecione **Deploy from a branch**, escolha a branch `main` e a pasta `/(root)`, depois toque em **Save**.
6. Aguarde a publicação e abra o endereço indicado na página do GitHub Pages.
7. No Chrome do Android, abra o site e use o menu ⋮ → **Adicionar à tela inicial** (ou **Instalar app**, se aparecer).

## Importante
- A lista e os detalhes são carregados pela PokéAPI, então a primeira utilização precisa de internet.
- Favoritos e capturados são salvos neste navegador/dispositivo. Esta versão ainda não tem login nem sincronização entre dispositivos; isso exige configurar um serviço de autenticação e banco de dados.
- O projeto é de fã, não oficial e não afiliado à Nintendo, Game Freak ou The Pokémon Company.
